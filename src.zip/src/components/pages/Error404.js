import React from "react";

export default function Error404() {
  return (
    <div className="error404">
      <img
        src="https://www.artzstudio.com/wp-content/uploads/2020/05/404-error-not-found-page-lost-1024x788.png"
        alt=""
      />
    </div>
  );
}
