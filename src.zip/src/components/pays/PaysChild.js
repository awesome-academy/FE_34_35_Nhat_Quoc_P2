import React from "react";
import { useTranslation } from "react-i18next";
import { Link } from "react-router-dom";

const PaysChild = () => {
  const { t } = useTranslation("common");

  return (
    <div>
      <div className="breadcrumbs">
        <div className="container">
          <div className="breadcrumbs__link">
            <Link to="/">{t("breadcrumbs.home")}</Link>
            <Link to="/">{t("breadcrumbs.listDetails")}</Link>
            <Link to="/">{t("breadcrumbs.buyTicket")}</Link>
            <Link to="/">{t("breadcrumbs.chooseSeats")}</Link>
            <Link to="/">{t("breadcrumbs.pays")}</Link>
          </div>
        </div>
      </div>
      <div className="pay">
        <div className="container">
          <div className="pay__grid">
            <div className="frame-choose">
              <div className="frame-choose__inner">
                <h3 className="frame-choose__title">
                  {t("titleBooking.choosePays")}
                </h3>
                <form className="pay__form">
                  <div className="pay__group">
                    <label>{t("pays.payments")}</label>
                    <select>
                      <option value="choose-card">Choose Card</option>
                      <option value="momo">MoMo</option>
                      <option value="onepay-atm">OnePay-ATM Card</option>
                      <option value="zalopay-atm">
                        ZaloPay- ATM Card/Visa/Master
                      </option>
                    </select>
                  </div>
                  <div className="pay__group">
                    <label>{t("pays.fullName")}</label>
                    <input type="text" placeholder="Full Name" />
                  </div>
                  <div className="pay__group">
                    <label>{t("pays.email")}</label>
                    <input type="text" placeholder="Email" />
                  </div>
                  <div className="pay__group">
                    <label>{t("pays.phone")}</label>
                    <input type="text" placeholder="Phone" />
                  </div>
                  <div className="pay__note">
                    (*) Bằng việc click/chạm vào THANH TOÁN, bạn đã xác nhận
                    hiểu rõ các <Link to="/">Quy Định Giao Dịch</Link> Trực
                    Tuyến.
                  </div>
                  <div className="pay__button">
                    <button>{t("button.back")}</button>
                    <button>{t("button.pay")}</button>
                  </div>
                </form>
              </div>
            </div>
            <div className="buy-ticket__sidebar">
              <div className="ticket-movie__wrap">
                <div className="ticket-movie__feature">
                  <Link to="/">
                    <img src="assets/images/poster_movie/01.jpg" alt="images" />
                  </Link>
                </div>
                <div className="ticket-movie__detail">
                  <h3 className="ticket-movie__movie-name">CINEMA NAME</h3>
                  <ul className="ticket-movie__info">
                    <li className="ticket-movie__theater">
                      <span className="ticket-movie__title">
                        {t("buyTicket.cinema")}
                      </span>
                      <span></span>
                    </li>
                    <li className="ticket-movie__showshow">
                      <span className="ticket-movie__title">
                        {t("buyTicket.screening")}
                      </span>
                      <span></span>
                    </li>
                    <li className="ticket-movie__date">
                      <span className="ticket-movie__title">
                        {t("buyTicket.date")}
                      </span>
                      <span></span>
                    </li>
                    <li className="ticket-movie__combo">
                      <span className="ticket-movie__title">
                        {t("buyTicket.combo")}
                      </span>
                      <span></span>
                    </li>
                    <li className="ticket-movie__seat">
                      <span className="ticket-movie__title">
                        {t("buyTicket.seat")}
                      </span>
                      <span></span>
                    </li>
                    <li className="ticket-movie__total">
                      <span className="ticket-movie__title">
                        {t("buyTicket.total")}
                      </span>
                      <span></span>
                    </li>
                  </ul>
                  <div className="ticket-movie__button">
                    <Link to="/choose-seats">{t("button.continue")}</Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PaysChild;
